# Legacy JavaScript and TypeScript Lab Notes

## Task 1 — jQuery test

The temporary implementation is available as `public/legacy-feedback.js` (with an archival copy in `legacy/`). To reproduce the legacy stage, add `novalidate` to the form (already present in `public/index.html`), then temporarily add these scripts before `</body>`:

```html
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="legacy-feedback.js"></script>
```

Open the page, submit an empty form, then enter valid and invalid values. The script displays inline errors and prevents submission. The final project does **not** load jQuery.

## Task 2 — Six jQuery calls and native equivalents

| jQuery call | Native JavaScript equivalent |
|---|---|
| `$(selector)` | `document.querySelector(selector)` or `document.querySelectorAll(selector)` |
| `$(fn)` / `$(document).ready(fn)` | `document.addEventListener("DOMContentLoaded", fn)`; with a module script at the end of the body, the DOM is already parsed |
| `.on("click", handler)` | `.addEventListener("click", handler)` |
| `.val()` | `element.value` |
| `.text(value)` | `element.textContent = value` |
| `.addClass("error")` | `element.classList.add("error")` |
| `.removeClass("error")` | `element.classList.remove("error")` |
| `.attr("aria-invalid", "true")` | `element.setAttribute("aria-invalid", "true")` |

Three legacy smells:

1. **Library dependency for basic DOM work:** simple selection and event handling require jQuery.
2. **Repeated global selectors:** repeatedly querying the same elements makes code harder to maintain.
3. **Untyped, loosely structured callbacks:** values and DOM assumptions are not checked by a compiler.

## Task 3 — Native port and Network panel

The final page loads `js/main.js` and `js/feedback.js`, compiled from `src/main.ts` and `src/feedback.ts`. There is no jQuery script tag and no jQuery import. In browser DevTools, open **Network**, enable **Disable cache**, reload, and filter for `jquery`. The expected result is **0 requests**.

## Task 4 — Error styles

`public/style.css` defines `--color-error` in `:root` and applies it to `.error`, `input[aria-invalid="true"]`, and `textarea[aria-invalid="true"]`. The supplied starter did not include Figure 1, so the exact visual comparison cannot be verified here. Compare the red border and error text against your instructor's figure.

## Task 5 — TypeScript setup

`package.json` includes `build` and `typecheck`; `tsconfig.json` enables `"strict": true`.

Run:

```bash
npm install
npm run typecheck
npm run build
```

## Task 6 — Moving scripts and initial errors

The three maintained scripts are now `src/main.ts`, `src/utils.ts`, and `src/feedback.ts`. They are compiled into `public/js/`.

Two common errors from the initial untyped starter when strict TypeScript is enabled are:

1. `TS7006: Parameter 'ms' implicitly has an 'any' type.` — annotate `ms` as `number`.
2. `TS18047` / `TS2531: Object is possibly 'null'.` — `querySelector()` may return `null`; check it or use the generic `getRequired<T>()` helper.

These are recorded as representative strict-mode issues; exact diagnostics depend on which file is converted first.

## Task 7 — Typed utilities

`delay(ms: number): Promise<void>` and `makeCounter(start: number = 0): () => number` are typed in `src/utils.ts`. `getRequired<T extends Element>()` returns a matching element or throws a useful error if it is missing.

## Task 8 — Structural typing

`Slot` describes `day`, `session`, and `seats`. The `booking` object also has a `room` property. It can still be passed to `describeSlot()` because TypeScript uses structural typing: an object is compatible when it has the required members with compatible types; extra properties are allowed.

Example of an intentional error to read:

```ts
const invalidBooking = {
  day: "Monday",
  session: "HTML & CSS",
  seats: "twelve"
};
describeSlot(invalidBooking);
```

The error is that `seats` is a string but `Slot.seats` must be a number (typically TS2345).

## Task 9 — Typed main module

`src/main.ts` narrows `event.target` with `instanceof Element`, checks the result of `closest()`, and verifies that the row exists before using it. `getRequired<HTMLElement>()` handles required page elements.

## Task 10 — Typed feedback module

`src/feedback.ts` uses typed helper functions, a `FieldRule` interface, typed input elements, and `getRequired<T>()`. It validates name, email, and message, updates `aria-invalid`, and moves focus to the first invalid field.

## Task 11 — Build and deliberate type error

Run `npm run build`. To demonstrate a deliberate type error, temporarily change this line in `src/utils.ts`:

```ts
export function delay(ms: number): Promise<void> {
```

to:

```ts
export function delay(ms: string): Promise<void> {
```

Then run `npm run typecheck`. Calls such as `delay(1000)` should fail because a number is not assignable to string (TS2345). Restore `ms: number`, then run `npm run typecheck` and `npm run build` again. The page should load from a local static server.

## Task 12 — Accessibility, Lighthouse, Git

Keyboard check:

- Press Tab and Shift+Tab to move through links, buttons, and form controls.
- Confirm the visible focus outline.
- Submit the empty form and confirm focus moves to the first invalid field.
- Confirm errors are announced through the status and error text.

Run Lighthouse in Chrome DevTools → Lighthouse → Navigation → Desktop or Mobile, then Generate report. The score is environment-dependent; do not claim 100 unless your actual report shows 100. If the score is lower, inspect the report's opportunities and diagnostics.

Git commands (run from the project root):

```bash
git init
git add src/ public/ tsconfig.json package.json package-lock.json LEGACY-NOTES.md legacy/
git commit -m "Complete web engineering TypeScript lab"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/web-engineering-lab.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If the repository already exists locally, do not run `git init` or add a second remote; use `git add`, `git commit`, and `git push`.
