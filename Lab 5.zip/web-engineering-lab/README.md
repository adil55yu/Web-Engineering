# Web Engineering Lab

## Requirements
- Node.js and npm
- A modern browser

## Setup

```bash
npm install
npm run typecheck
npm run build
```

Serve the project root with a local static server, then open `public/` as the web root. For example, from the project root:

```bash
npx serve public
```

The final site uses native JavaScript compiled from TypeScript. jQuery is intentionally absent from the final page. See `LEGACY-NOTES.md` for the staged legacy comparison, testing steps, and submission checklist.
