// Task 1: temporary jQuery version. Use only while completing the legacy comparison.
$(function () {
  $("#feedback-form").on("submit", function (event) {
    event.preventDefault();

    const name = $("#name").val().trim();
    const email = $("#email").val().trim();
    const message = $("#message").val().trim();

    $(".error-message").text("");
    $("input, textarea").removeClass("error").removeAttr("aria-invalid");

    let valid = true;

    if (name.length < 2) {
      $("#name-error").text("Please enter at least 2 characters.");
      $("#name").addClass("error").attr("aria-invalid", "true");
      valid = false;
    }

    if (!/^[^\s@]+@[^\s@]+\\.[^\s@]+$/.test(email)) {
      $("#email-error").text("Please enter a valid email address.");
      $("#email").addClass("error").attr("aria-invalid", "true");
      valid = false;
    }

    if (message.length < 10) {
      $("#message-error").text("Please enter at least 10 characters.");
      $("#message").addClass("error").attr("aria-invalid", "true");
      valid = false;
    }

    $("#feedback-status").text(
      valid ? "Thank you! Your feedback has been submitted." :
              "Please correct the highlighted fields."
    );
  });
});
