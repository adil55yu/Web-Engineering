import { getRequired } from "./utils.js";
const form = getRequired("#feedback-form");
const feedbackStatus = getRequired("#feedback-status");
function getField(name, selector) {
    const field = getRequired(selector);
    const error = getRequired(`#${name}-error`);
    field.setAttribute("aria-invalid", "false");
    error.textContent = "";
    return field;
}
function validateName(value) {
    return value.trim().length >= 2 ? "" : "Please enter at least 2 characters.";
}
function validateEmail(value) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(value.trim()) ? "" : "Please enter a valid email address.";
}
function validateMessage(value) {
    return value.trim().length >= 10 ? "" : "Please enter at least 10 characters.";
}
const nameInput = getField("name", "#name");
const emailInput = getField("email", "#email");
const messageInput = getField("message", "#message");
const fields = [
    {
        input: nameInput,
        error: getRequired("#name-error"),
        validate: validateName
    },
    {
        input: emailInput,
        error: getRequired("#email-error"),
        validate: validateEmail
    },
    {
        input: messageInput,
        error: getRequired("#message-error"),
        validate: validateMessage
    }
];
function showFieldError(field, message) {
    field.error.textContent = message;
    field.input.setAttribute("aria-invalid", String(message.length > 0));
    field.input.classList.toggle("error", message.length > 0);
}
function validateField(field) {
    const message = field.validate(field.input.value);
    showFieldError(field, message);
    return message.length === 0;
}
fields.forEach((field) => {
    field.input.addEventListener("input", () => {
        validateField(field);
    });
});
form.addEventListener("submit", (event) => {
    event.preventDefault();
    const isValid = fields.map(validateField).every(Boolean);
    if (!isValid) {
        feedbackStatus.textContent = "Please correct the highlighted fields.";
        const firstInvalid = form.querySelector('[aria-invalid="true"]');
        firstInvalid?.focus();
        return;
    }
    feedbackStatus.textContent = "Thank you! Your feedback has been submitted.";
    form.reset();
    fields.forEach((field) => {
        showFieldError(field, "");
        field.input.setAttribute("aria-invalid", "false");
    });
});
