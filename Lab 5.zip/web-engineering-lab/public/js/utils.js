export function delay(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
}
export function makeCounter(start = 0) {
    let count = start;
    return function () {
        count += 1;
        return count;
    };
}
export function getRequired(selector) {
    const element = document.querySelector(selector);
    if (!element) {
        throw new Error(`Required element not found: ${selector}`);
    }
    return element;
}
export function describeSlot(slot) {
    return `${slot.session} on ${slot.day} (${slot.seats} seats available)`;
}
const booking = {
    day: "Monday",
    session: "HTML & CSS",
    seats: 12,
    room: "Lab 2"
};
export const bookingDescription = describeSlot(booking);
