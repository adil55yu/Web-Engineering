import { getRequired } from "./utils.js";

type FeedbackFieldName = "name" | "email" | "message";

interface FieldRule {
  input: HTMLInputElement | HTMLTextAreaElement;
  error: HTMLElement;
  validate: (value: string) => string;
}

const form = getRequired<HTMLFormElement>("#feedback-form");
const feedbackStatus = getRequired<HTMLElement>("#feedback-status");

function getField<T extends HTMLInputElement | HTMLTextAreaElement>(
  name: FeedbackFieldName,
  selector: string
): T {
  const field = getRequired<T>(selector);
  const error = getRequired<HTMLElement>(`#${name}-error`);
  field.setAttribute("aria-invalid", "false");
  error.textContent = "";
  return field;
}

function validateName(value: string): string {
  return value.trim().length >= 2 ? "" : "Please enter at least 2 characters.";
}

function validateEmail(value: string): string {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(value.trim()) ? "" : "Please enter a valid email address.";
}

function validateMessage(value: string): string {
  return value.trim().length >= 10 ? "" : "Please enter at least 10 characters.";
}

const nameInput = getField<HTMLInputElement>("name", "#name");
const emailInput = getField<HTMLInputElement>("email", "#email");
const messageInput = getField<HTMLTextAreaElement>("message", "#message");

const fields: FieldRule[] = [
  {
    input: nameInput,
    error: getRequired<HTMLElement>("#name-error"),
    validate: validateName
  },
  {
    input: emailInput,
    error: getRequired<HTMLElement>("#email-error"),
    validate: validateEmail
  },
  {
    input: messageInput,
    error: getRequired<HTMLElement>("#message-error"),
    validate: validateMessage
  }
];

function showFieldError(field: FieldRule, message: string): void {
  field.error.textContent = message;
  field.input.setAttribute("aria-invalid", String(message.length > 0));
  field.input.classList.toggle("error", message.length > 0);
}

function validateField(field: FieldRule): boolean {
  const message = field.validate(field.input.value);
  showFieldError(field, message);
  return message.length === 0;
}

fields.forEach((field) => {
  field.input.addEventListener("input", () => {
    validateField(field);
  });
});

form.addEventListener("submit", (event: SubmitEvent) => {
  event.preventDefault();

  const isValid = fields.map(validateField).every(Boolean);

  if (!isValid) {
    feedbackStatus.textContent = "Please correct the highlighted fields.";
    const firstInvalid = form.querySelector<HTMLElement>('[aria-invalid="true"]');
    firstInvalid?.focus();
    return;
  }

  feedbackStatus.textContent = "Thank you! Your feedback has been submitted.";
  form.reset();

  fields.forEach((field) => {
    showFieldError(field, "");
    field.input.setAttribute("aria-invalid", "false");
  });
});
