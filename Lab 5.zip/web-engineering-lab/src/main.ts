import { delay, makeCounter, getRequired, describeSlot } from "./utils.js";

const schedule = getRequired<HTMLElement>("#schedule");
const status = getRequired<HTMLElement>("#booking-status");
const nextBookingNumber = makeCounter(0);

const exampleSlot = {
  day: "Wednesday",
  session: "JavaScript",
  seats: 8
};
console.log(describeSlot(exampleSlot));

schedule.addEventListener("click", async (event: MouseEvent): Promise<void> => {
  const target = event.target;

  if (!(target instanceof Element)) {
    return;
  }

  const button = target.closest<HTMLButtonElement>(".book-btn");

  if (!button || !schedule.contains(button)) {
    return;
  }

  const row = button.closest<HTMLTableRowElement>("tr");

  if (!row) {
    return;
  }

  const isSelected = row.classList.toggle("selected");
  const bookedRows = schedule.querySelectorAll("tr.selected").length;

  if (isSelected) {
    const bookingNumber = nextBookingNumber();
    const day = button.dataset.day ?? "Unknown day";

    button.disabled = true;
    status.textContent = `Booking #${bookingNumber} for ${day}...`;

    await delay(1000);

    button.textContent = `Booked #${bookingNumber}`;
    button.disabled = false;
    status.textContent =
      `Booking #${bookingNumber} confirmed for ${day}. ` +
      `${schedule.querySelectorAll("tr.selected").length} session(s) selected.`;
  } else {
    button.textContent = "Book";
    status.textContent = `${bookedRows} session${bookedRows === 1 ? "" : "s"} booked.`;
  }
});
