export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

export function makeCounter(start: number = 0): () => number {
  let count = start;

  return function (): number {
    count += 1;
    return count;
  };
}

export function getRequired<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);

  if (!element) {
    throw new Error(`Required element not found: ${selector}`);
  }

  return element;
}

export interface Slot {
  day: string;
  session: string;
  seats: number;
}

export function describeSlot(slot: Slot): string {
  return `${slot.session} on ${slot.day} (${slot.seats} seats available)`;
}

const booking = {
  day: "Monday",
  session: "HTML & CSS",
  seats: 12,
  room: "Lab 2"
};

export const bookingDescription = describeSlot(booking);
