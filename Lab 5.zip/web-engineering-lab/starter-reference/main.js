
import { delay, makeCounter } from "./utils.js";

const schedule = document.querySelector("#schedule");
const status = document.querySelector("#booking-status");
const nextBookingNumber = makeCounter(0);

schedule.addEventListener("click", async (event) => {
  const button = event.target.closest(".book-btn");

  if (!button || !schedule.contains(button)) return;

  const row = button.closest("tr");
  if (!row) return;

  const isSelected = row.classList.toggle("selected");
  const bookedRows = schedule.querySelectorAll("tr.selected").length;

  if (isSelected) {
    const bookingNumber = nextBookingNumber();
    const day = button.dataset.day;

    button.disabled = true;
    status.textContent = `Booking #${bookingNumber} for ${day}...`;

    await delay(1000);

    button.textContent = `Booked #${bookingNumber}`;
    button.disabled = false;

    status.textContent =
      `Booking #${bookingNumber} confirmed for ${day}. ` +
      `${schedule.querySelectorAll("tr.selected").length} session(s) selected.`;
  } else {
    button.textContent = "Book";
    status.textContent = `${bookedRows} session${bookedRows === 1 ? "" : "s"} booked.`;
  }
});
